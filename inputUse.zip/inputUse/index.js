const prompt = require('prompt-sync')();

let name=prompt("Enter Your University Name:");
console.log(name);